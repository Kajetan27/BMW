. Strona główna 

Prezentuje główny model BMW X3 z dużym zdjęciem.

Pokazuje aktualną ofertę finansowania (np. cena za miesiąc, leasing).

Zawiera przyciski:

„Skonfiguruj” → prowadzi do podstrony modele.html

„Dowiedz się więcej” → prowadzi do podstrony modele.html

Menu z odnośnikami do wszystkich podstron.

Estetyczny wygląd: ciemne tło, niebieskie akcenty, nowoczesny font.

2. Modele i Konfigurator 

Opisuje różne modele BMW (przykładowo BMW X5).

Pokazuje zdjęcie samochodu.

Tekst informacyjny: „Skorzystaj z konfiguratora, aby stworzyć auto swoich marzeń”.

Przycisk/odnośnik: powrót do strony głównej.

3. Sklep Connected Drive 

Prezentuje ofertę usług i technologii BMW Connected Drive.

Zdjęcie przykładowego samochodu.

Tekst informacyjny: „Odkryj szeroką ofertę usług Connected Drive”.

4. Elektryczne 

Pokazuje linię samochodów elektrycznych BMW.

Zdjęcie samochodu elektrycznego.

Tekst informacyjny: „Łączy wydajność z ekologią i nowoczesnym designem”.

5. Oferty online 

Informacje o promocjach i ofertach specjalnych dostępnych online.

Zdjęcie przykładowego samochodu w promocji.

Tekst informacyjny: „Sprawdź najnowsze promocje i oferty specjalne”.

6. Świat BMW 

Pokazuje historię i filozofię marki BMW.

Zdjęcie samochodu lub logo BMW.

Tekst informacyjny: „Poznaj historię, wartości i pasję, które stoją za marką BMW”.

Cechy i funkcjonalności strony

Responsywna: działa na komputerach, tabletach i telefonach.

Menu nawigacyjne działa i przenosi między podstronami.

Wszystkie zdjęcia ładowane są z internetu — nie trzeba ich wklejać lokalnie.

Estetyczny wygląd: ciemne tło, niebieskie akcenty, nowoczesne fonty.

Podstrony mają przyciski do powrotu na stronę główną.

Strona gotowa do rozbudowy o dodatkowe funkcje, np. slider zdjęć, przyciski „kup teraz”, formularze kontaktowe.